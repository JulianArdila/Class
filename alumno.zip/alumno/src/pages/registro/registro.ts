import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { LoginPage } from '../login/login';
/**
 * Generated class for the RegistroPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-registro',
  templateUrl: 'registro.html',
})
export class RegistroPage {
  nombre: String;
  apellido: String;
  correo: String;
  fecha_de_nacimiento: Date;
  phone: String;
  cc: String;
  usuario: String;
  clave: String;
  constructor(public navCtrl: NavController, public navParams: NavParams, public restProvider: RestProvider) {
  }


  iniciarRegistro() {
    var data = {
      'first_name': this.nombre,
      'last_name': this.apellido,
      'email': this.correo,
      'is_active': 1,
      'birthday': this.fecha_de_nacimiento,
      'username': this.usuario,
      'password': this.clave,
      'phone': this.phone,
      'cc': this.cc,
    };
    this.restProvider.registro(data).then((result: any) => {
      console.log(result);
      this.navCtrl.setRoot(LoginPage);
    }, (err) => {
      console.log(err);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegistroPage');
  }

}
