import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlumnoFormPage } from './alumno-form';

@NgModule({
  declarations: [
    AlumnoFormPage,
  ],
  imports: [
    IonicPageModule.forChild(AlumnoFormPage),
  ],
})
export class AlumnoFormPageModule {}
