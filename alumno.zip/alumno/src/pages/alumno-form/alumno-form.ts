import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';

import { Camera, CameraOptions } from '@ionic-native/camera';
/**
 * Generated class for the AlumnoFormPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-alumno-form',
  templateUrl: 'alumno-form.html',
})
export class AlumnoFormPage {
  options: CameraOptions = {
    quality: 70,
    targetWidth: 500,
    targetHeight: 500,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE
  }
  imagen: any;
  nombre: String;
  codigo: String;
  curso: String;

  constructor(public navCtrl: NavController, public navParams: NavParams, private camera: Camera, public restProvider: RestProvider) {
  }

  tomarFoto() {
    this.camera.getPicture(this.options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64 (DATA_URL):
      this.imagen = 'data:image/jpeg;base64,' + imageData;
    }, (err) => {
      console.log(err);
    });
  }

  iniciarRegistro() {
    var data = {
      'nombre': this.nombre,
      'codigo': this.codigo,
      'curso': this.curso,
      'estado': 1,
      'imagen': this.imagen
    };
    this.restProvider.alumnos(data).then((result: any) => {
      console.log(result);
      //this.navCtrl.setRoot(LoginPage);
    }, (err) => {
      console.log(err);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AlumnoFormPage');
  }

}
