import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { AlumnoFormPage } from '../alumno-form/alumno-form';

/**
 * Generated class for the AlumnosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-alumnos',
  templateUrl: 'alumnos.html',
})
export class AlumnosPage {
  
  alumnos: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public restProvider: RestProvider) {
  }

  redirectToForm(){
    this.navCtrl.push(AlumnoFormPage);
  }

  ionViewDidLoad() {
    this.consultarAlumnos();
  }
  consultarAlumnos() {
    this.restProvider.getAlumnos()
      .then(data => {
        this.alumnos = data;
        console.log(this.alumnos[0].nombre);
      });
  }
}
