cordova.define("cordova-plugin-googlemaps.MapTypeId", function(require, exports, module) { module.exports = {
  'NORMAL': 'MAP_TYPE_NORMAL',
  'ROADMAP': 'MAP_TYPE_NORMAL',
  'SATELLITE': 'MAP_TYPE_SATELLITE',
  'HYBRID': 'MAP_TYPE_HYBRID',
  'TERRAIN': 'MAP_TYPE_TERRAIN',
  'NONE': 'MAP_TYPE_NONE'
};

});
