import React from 'react';
import { StyleSheet, Dimensions, TextInput, Text, View } from 'react-native';

export default function InputComponent(props) {
    var type = 'red';
    if ('type' in props) {
        type = props['type']
    }
    var security = false;
    if (props.security) {
        security = props.security
    }
    var placeholder = '';
    if (props.placeholder) {
        placeholder = props.placeholder
    }
    return (
        <View>
            <Text><label>{placeholder}</label></Text>
            <TextInput style={styles.input} textContentType={type} secureTextEntry={security} placeholder={placeholder} onChangeText={props.action} />
        </View>
    );
}
const styles = StyleSheet.create({
    input: {
        borderWidth: 1,
        borderColor: '#777',
        padding: 8,
        margin: 10,
        width: Dimensions.get('window').width * 0.85,
    },
});
