import React, { Component } from 'react';
import { StyleSheet, Dimensions, View, Button } from 'react-native';

const styles = StyleSheet.create({
    button: {
        width: Dimensions.get('window').width * 0.85,
        padding: 8,
        marginTop: 10,
    },
});

export default class ButtonComponent extends Component {
    constructor(props) {
        super(props);
        this.color = 'red';
        if (props.color) {
            this.color = props.color
        }
        this.title = 'Rojo';
        if (props.title) {
            this.title = props.title
        }
        this.action = props.action
    }
    
    render() {
        return (
            <View style={styles.button}>
                <Button color={this.color} title={this.title} onPress={this.action} />
            </View>
        );
    }
}