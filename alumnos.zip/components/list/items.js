import React from 'react';
import { StyleSheet, Dimensions, Text, View } from 'react-native';

const styles = StyleSheet.create({
    item: {
        flex: 1,
        marginHorizontal: 10,
        marginTop: 24,
        padding: 30,
        backgroundColor: '#d4ecf5',
        fontSize: 24,
    },
    principal: {
        fontSize: 24,
        // display: 'block',
        fontWeight: 'bold',
    }
});

export default function ItemComponent(props) {
    var principal = props.principal;
    var secundary = props.secundary;
    return (
        <View style={styles.item}>
            <Text style={styles.principal}>{principal}</Text>
            <Text>{secundary}</Text>
        </View>
    );
}
