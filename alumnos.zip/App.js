import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, Alert } from 'react-native';
import Login from './screens/login/login';

export default class App extends Component {
  render() {
    return (
      <Login />
    );
  }
}
