import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import ButtonComponent from '../components/forms/buttons';

export default class Home1 extends Component {
    render() {
        console.log(this.props.navigation)
        return (
            <View style={styles.container}>
                <Text>Hola Mundo!</Text>
                <ButtonComponent action={() => this.props.navigation.push('LoginWorkFlow')} />
                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    }
});