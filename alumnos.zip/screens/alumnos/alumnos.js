import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Text, View, FlatList } from 'react-native';
import Conection from '../../conections/api';
import ItemComponent from '../../components/list/items';

export default class Alumnos extends Component {
    constructor(props) {
        super(props);
        Conection({
            link: 'v2/alumnos/', headers: {
                'Authorization': 'token ' + window.localStorage['token']
            }
        }).then(data => {
            this.alumnos = data;
            console.log(this.alumnos);
            this.forceUpdate();
        });
    }

    render() {
        return (
            <View style={styles.container}>
                <FlatList
                    numColumns={1}
                    keyExtractor={(item) => item.id}
                    data={this.alumnos}
                    renderItem={({ item }) => (
                        <ItemComponent principal={item.nombre} secundary={item.curso} />
                    )} />
                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
        paddingHorizontal: 20,
        backgroundColor: '#fff',
    }, item: {
        flex: 1,
        marginHorizontal: 10,
        marginTop: 24,
        padding: 30,
        backgroundColor: '#d4ecf5',
        fontSize: 24,
    },
});