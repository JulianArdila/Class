import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, View, AsyncStorage } from 'react-native';
import InputComponent from '../../components/forms/inputs';
import ButtonComponent from '../../components/forms/buttons';
import Conection from '../../conections/api';

export default class Login extends Component {
    constructor(props) {
        super(props);
        AsyncStorage.getItem('token').then(token => {
            console.log(token);
            if (token) {
                this.props.navigation.replace('MainWorkFlow');
            }
        })
        this.username = "";
        this.password = "";


        this.button_list = [
            {
                color: "rgb(16, 0, 255)",
                title: "Log in",
                action: () => this.Login(),
            },
            {
                'color': "grey",
                'title': "Registro",
                'action': () => this.redirectToRegister(),
            }
        ];

        this.input_list = [
            {
                type: "username",
                placeholder: "Nombre de Usuario",
                action: (val) => this.setValue('username', val),
            },
            {
                type: "password",
                security: true,
                placeholder: "Contraseña",
                action: (val) => this.setValue('password', val),
            },
        ];

    }

    setValue(key, val = '') {
        this[key] = val;
        this.forceUpdate();
    }

    async Login() {
        const data = {
            password: this.password,
            username: this.username
        };
        const result = await Conection({
            link: 'api/login/', method: 'POST', data: data, headers: {}
        });
        console.log(result);
        if ('key' in result) {
            AsyncStorage.setItem(
                'token',
                result['key']
            );
        } else {
            this.forceUpdate();
        }
    }


    redirectToRegister() {
        this.props.navigation.navigate('Registro')
        console.log('Voy a Registro');
    }

    render() {
        return (
            <View style={styles.container}>

                {this.input_list.map(data => <InputComponent type={data.type} security={data.security} placeholder={data.placeholder} action={data.action} />)}
                {this.button_list.map(data => <ButtonComponent color={data.color} title={data.title} action={data.action} />)}

                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        backgroundColor: '#fff',
        padding: 8,
        margin: 10,
    }
});