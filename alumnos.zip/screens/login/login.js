import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Dimensions, View, Button, TextInput } from 'react-native';
import InputComponent from '../../components/forms/inputs';
import ButtonComponent from '../../components/forms/buttons';


export default class Login extends Component {
    constructor(props) {
        super(props);
        this.username = "";
        this.password = "";


        this.button_list = [
            {
                color: "rgb(16, 0, 255)",
                title: "Log in",
                action: this.Login,
            },
            {
                'color': "grey",
                'title': "Registro",
                'action': this.redirectToRegister,
            }
        ];

        this.input_list = [
            {
                type: "username",
                placeholder: "Nombre de Usuario",
                action: (val) => this.setValue('username', val),
            },
            {
                type: "password",
                security: true,
                placeholder: "Contraseña",
                action: (val) => this.setValue('password', val),
            },
        ];

    }

    setValue(key, val = '') {
        console.log(key);
        console.log(this[key]);
        console.log(this)
        this[key] = val;
        this.forceUpdate();
    }

    Login() {
        //console.log(this.password);
        //console.log(this.username);
        console.log('Voy a Ingresar');
    }

    redirectToRegister() {
        //this.props.navigation.navigate('Registro')
        console.log('Voy a Registro');
    }

    render() {
        return (
            <View style={styles.container}>
                {this.input_list.map(data => <InputComponent type={data.type} security={data.security} placeholder={data.placeholder} action={data.action} />)}
                {this.button_list.map(data => <ButtonComponent color={data.color} title={data.title} action={data.action} />)}

                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        backgroundColor: '#fff',
        padding: 8,
        margin: 10,
    },
    input: {
        borderWidth: 1,
        borderColor: '#777',
        padding: 8,
        margin: 10,
        width: Dimensions.get('window').width * 0.85,
    },
    button: {
        width: Dimensions.get('window').width * 0.85,
        padding: 8,
        marginTop: 10,
    },
});