import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput } from 'react-native';
import ButtonComponent from '../../components/forms/buttons';

export default class Registro extends Component {

    redirectToLogin() {
        this.props.navigation.navigate('Login');
        console.log('Voy a Login');
    }

    render() {
        return (
            <View style={styles.container}>
                <Text>Registro</Text>
                <ButtonComponent action={() => this.props.navigation.goBack('Login')} />
                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
})