import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import InputComponent from '../../components/forms/inputs';
import ButtonComponent from '../../components/forms/buttons';
import DateTimePicker from '@react-native-community/datetimepicker';
import Conection from '../../conections/api';

export default class Registro extends Component {

    constructor(props) {
        super(props);
        this.show = false;
        this.date_initial = new Date();
        this.nacimiento = null;
        this.nombre = null;
        this.apellido = null;
        this.correo = null;
        this.phone = null;
        this.cc = null;
        this.usuario = null;
        this.clave = null;
        this.inputs = [
            {
                type: "name",
                placeholder: "Nombre",
                action: (val) => this.setValue('nombre', val)
            },
            {
                type: "name",
                placeholder: "Apellido",
                action: (val) => this.setValue('apellido', val)
            },
            {
                type: "emailAddress",
                placeholder: "Correo",
                keyboard_type: "email-address",
                action: (val) => this.setValue('correo', val)
            },
            {
                type: "telephoneNumber",
                placeholder: "Telefono",
                keyboard_type: "phone-pad",
                action: (val) => this.setValue('phone', val)
            },
            {
                type: "text",
                placeholder: "Cedula",
                keyboard_type: "number-pad",
                action: (val) => this.setValue('cc', val)
            },
            {
                type: "username",
                placeholder: "Nombre de Usuario",
                action: (val) => this.setValue('usuario', val)
            },
            {
                type: "newPassword",
                placeholder: "Contraseña",
                action: (val) => this.setValue('clave', val)
            }
        ];
    }

    setValue(key, val = '') {
        this[key] = val;
        this.forceUpdate();
    }

    redirectToLogin() {
        this.props.navigation.navigate('Login');
    }

    Registrar() {
        console.log("Registrando");
        console.log((this.nacimiento.getMonth() + 1) + '/' + this.nacimiento
            .getDate() + '/' + this.nacimiento.getFullYear());
        let date = "";
        if (this.nacimiento != null) date = this.nacimiento.getFullYear() +
            '-' + (this.nacimiento.getMonth() + 1) + '-' + this.nacimiento.getDate();
        const data = {
            'birthday': date,
            'first_name': this.nombre,
            'last_name': this.apellido,
            'email': this.correo,
            'is_active': 1,
            'phone': this.phone,
            'cc': this.cc,
            'username': this.usuario,
            'password': this.clave,
        };
        console.log(data);
        Conection({
            link: 'v2/user/', method: 'POST', data: data, headers: {}
        }).then((result) => {
            console.log(result);
            // await this.props.navigation.replace('MainWorkFlow');
        });

    }

    getDate(event, selectedDate) {
        console.log(selectedDate);
        this.show = false;
        if (selectedDate) {
            this.setValue('date_initial', selectedDate);
            this.setValue('nacimiento', selectedDate);
        }
    }
    showInput() {
        this.show = true;
        this.forceUpdate();
    }

    render() {
        return (
            <View style={styles.container}>
                <ScrollView style={styles.scrollView}>
                    {this.inputs.map(item =>
                        <InputComponent type={item.type}
                            placeholder={item.placeholder}
                            action={item.action}
                            keyboard_type={item.keyboard_type} />)}
                    {this.nacimiento && (
                        <Text>La fecha que ha elegido es: {this.nacimiento.toLocaleDateString()}</Text>
                    )}

                    <ButtonComponent action={() => this.showInput()} title="Elegir fecha de nacimiento" color="#7BC9F7" />
                    {this.show && (
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={this.date_initial}
                            mode='date'
                            display="calendar"
                            onChange={(event, selectedDate) => this.getDate(event, selectedDate)}
                        />)}
                </ScrollView>

                <ButtonComponent action={() => this.Registrar()} title="Guardar Usuario" color="green" />
                <StatusBar style="auto" />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    scrollView: {
        marginHorizontal: 5,
        marginVertical: 10,
    },

})