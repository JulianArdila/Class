const Conection = (parameters) => {
    const apiUrl = "http://192.168.0.25:8000/";
    parameters['headers'].Accept = 'application/json';
    parameters['headers']['Content-Type'] = 'application/json';
    
    var myHeaders = new Headers(parameters['headers']);
    var method = "GET";
    if ('method' in parameters) {
        var method = parameters['method'];
    }
    var props = {
        method: method,
        headers: myHeaders,
    }
    if ('data' in parameters) props.body = JSON.stringify(parameters['data']);
    return fetch(apiUrl + parameters['link'], props)
    .then((response) => response.json())
    .catch((error) => console.error(error));
}
export default Conection;
