import React from 'react';
import Home from '../screens/home';
import Home1 from '../screens/home1';
import AlumnoStack from './AlumnosRouting';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

export default function HomeStack() {
    return (
        <Tab.Navigator>
            <Tab.Screen name="Home1" component={Home1} />
            <Tab.Screen name="Home" component={Home} />
            <Tab.Screen name="HomeAlumnos" component={AlumnoStack} />
        </Tab.Navigator>
    );
}
