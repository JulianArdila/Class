import React, { Component } from 'react';
import Alumnos from '../screens/alumnos/alumnos';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

export default function AlumnoStack() {
    return (
        <Stack.Navigator>
            <Stack.Screen name="Alumnos" component={Alumnos} />
        </Stack.Navigator>
    );
}